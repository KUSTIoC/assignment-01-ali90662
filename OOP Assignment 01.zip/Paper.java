public class Paper 
{
    private String  paper_title;
    private String  course_code;
    private String  course_incharge;
    private String  semester;
    private String  type_of_exam;
    private String  location;
    private String  program_names;
    private String  invigilator;
    private int     paper_id_number;
    private int     number_of_students_in_the_paper;
    private int     day; 
    private int     month;
    private int     year;
    private int     hours;
    private int     minutes;
    private int     seconds;
    private boolean is_collected;

        public Paper 
        ( 
            String  paper_title,
            String  course_code,
            String  course_incharge,
            String  semester,
            String  type_of_exam,
            String  location,
            String  program_names,
            String  invigilator,
            int     paper_id_number,
            int     number_of_students_in_the_paper,
            int     day,
            int     month,
            int     year,
            int     hours,
            int     minutes,
            int     seconds,
            boolean is_collected
        ) 
        {
            this.paper_title = paper_title;
            this.course_code = course_code;
            this.course_incharge = course_incharge;
            this.semester = semester;
            this.program_names = program_names;
            this.type_of_exam = type_of_exam;
            this.location = location;
            this.invigilator = invigilator;
            this.paper_id_number = paper_id_number;
            this.number_of_students_in_the_paper = number_of_students_in_the_paper;
            this.day = day;
            this.month = month;
            this.year = year;
            this.hours=hours;
            this.minutes=minutes;
            this.seconds=seconds;
            this.is_collected = is_collected;
        }

        public void set_paper_title(String paper_title) 
        {
            this.paper_title = paper_title;
        }
        public String get_paper_title() 
        {
            return paper_title;
        }



        public void set_course_code(String course_code)
        {
            this.course_code = course_code;
        }
        public String get_course_code()
        {
            return course_code;
        }



        public void set_course_incharge(String course_incharge)
        {
            this.course_incharge = course_incharge;
        }
        public String get_course_incharge() 
        {
            return course_incharge;
        }




        public void set_semester(String semester)
        {
            this.semester = semester;
        }
        public String get_semester()
        {
            return semester;
        }



        public void set_program_names(String program_names)
        {
            this.program_names = program_names;
        }
        public String get_program_names()
        {
            return program_names;
        }




        public void set_type_of_exam(String type_of_exam)
        {
            this.type_of_exam = type_of_exam;
        }
        public String get_type_of_exam()
        {
            return type_of_exam;
        }




        public void set_location(String location)
        {
            this.location = location;
        }
        public String get_location()
        {
            return location;
        }



        public void set_paper_id_number(int paper_id_number)
        {
            this.paper_id_number = paper_id_number;
        }
        public int get_paper_id_number()
        {
            return paper_id_number;    
        }



        public void set_number_of_students_in_the_paper(int number_of_students_in_the_paper)
        {
            this.number_of_students_in_the_paper = number_of_students_in_the_paper;
        }
        public int get_number_of_students_in_the_paper()
        {
            return number_of_students_in_the_paper;
        }




        public void set_year(int day,int month,int year)
        {
            this.day=day;
            this.month=month;
            this.year = year;
        }
        public int get_day()
        {
            return day;
        }
        public int get_month()
        {
            return month;
        }
        public int get_year()
        {
            return year;
        }  



        public void set_time(int hours,int minutes,int seconds)
        {
            this.hours=hours;
            this.minutes=minutes;
            this.seconds = seconds;
        }
        public int get_hours() 
        {
            return hours;
        }
        public int get_minutes()
        {
            return minutes;
        }
        public int get_seconds()
        {
            return seconds;
        }



        public void set_is_collected(boolean is_collected)
        {
            this.is_collected = is_collected;
        }
        public boolean get_is_collected()
        {
            return is_collected;
        }

        
        @Override
        public String toString()
        {
            return "\n\n\n Paper Details : \n\n Paper Title = " + paper_title + " \n Course Code = " + course_code + "\n Course Incharge = " + course_incharge + "\n Semester = " + semester + "\n Prgaram Name = " + program_names + "\n Type Of Exam = " + type_of_exam + "\n Location = " + location + "\n Paper Id Number = " + paper_id_number + "\n Number Of Student In The Paper = " + number_of_students_in_the_paper + "\n Date = " + day + "/" + month + "/" + year + ",Time = " + hours + ":" + minutes + ":" + seconds+"\n Paper Collected = " + is_collected;
        }
        
    
}
