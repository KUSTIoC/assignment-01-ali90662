public class Test
{
    public static void main(String[] args)
    {
        
        Paper p1=new Paper("Web Designing","CS342","Sir Abdul Shahid","second","MID"," Conference Hall ","MCS","Maim Saima",662,18,6,7,2020,2,30,0,false);
        
        Paper p2=new Paper("Java","CS213","Sir Ali Zeb","2nd","Annual","2nd Floor,Room No. 3 ","MCS","Sir Adnan",737,15,7,7,2020,3,0,0,false);
        
        Paper p3=new Paper("Assembly Language","CS233","Sir Abrar","4th","Mid","Huawei Lab","MCS","Sir Gulzaib",881,14,8,7,2020,1,30,0,false);
        
        System.out.println(p1.toString());
        System.out.println(p2.toString());
        System.out.println(p3.toString());
                
        System.out.println(p2.toString()+new Course("Java","CS213","MCS"));
        System.out.println(p3.toString()+new Course("Assembly Language","CS233","MCS"));
    }
    
}
